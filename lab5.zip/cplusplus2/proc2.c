#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>

extern void f1(int), f2(int), f3(int);
int pid0, pid1, pid2;

int main(int argc, char* argv[]) {
    setpgrp();

    pid0 = getpid();
    pid1 = fork();

    if (pid1 == 0) {
      signal(SIGUSR1, f1);
      pid1 = getpid();
      pid2 = fork();

      if (pid2 < 0 ) {
        puts("Fork error");
      } else if (pid2 > 0) {
        for (;;);
      } else {
        signal(SIGUSR2, f2);
        pid2 = getpid();
        kill(pid1, SIGUSR1);
        for (;;);
      }
    } else {
      signal(SIGALRM, f3);
      alarm(10);
      pause();
    }

    return 0;
}

void f1(int signum)
{
    signal(SIGUSR1, f1);
    printf("Process 1 (%d) has got a signal from process 2 (%d)\n",pid1,pid2);
    sleep(1);
    kill(pid2, SIGUSR2);
}

void f2(int signum)
{
    signal(SIGUSR2, f2);
    printf("Process 2 (%d) has got a signal from process 1 (%d)\n",pid2,pid1);
    sleep(1);
    kill(pid1, SIGUSR1);
}

void f3(int signum)
{
    printf("End of job - %d\n", pid0);
    kill(0, SIGKILL);
}
