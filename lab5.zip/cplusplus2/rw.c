#include <stdio.h>

int main(int argc, char* argv[]) {
    if (argc < 2) {
      printf("Format: rw filename");
      return 4;
    }

    FILE* fp = fopen(argv[1], "w+");

    for (int i = 0, buff = 0; i < 10; i++) {
      printf("Write %d to %s\n", i, argv[1]);

      fprintf(fp, "%d\n", i);
      fseek(fp, -2, SEEK_CUR);
      fscanf(fp, "%d", &buff);

      printf("Read %d from %s\n", buff, argv[1]);
    }

    fclose(fp);

    printf("--------------------\n");
    return 0;
}
