#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char* argv[]) {
    printf("Process 1, pid = %d:\n", getpid());

    int pid2 = fork(), st;
    if (pid2 == 0) {
        printf("Process 2, pid = %d:\n", getpid());

        int pid3 = fork();
        if (pid3 == 0) {
          printf("Process 3, pid = %d:\n", getpid());
          sleep(2);
          printf("Process 3: end\n");
        } else if (pid3 < 0) {
          printf("Can't create process 3: error %d\n", pid3);
        }

        wait(&st);
        printf("Process 2: end\n");
    } else if (pid2 < 0) {
      printf("Can't create process 2: error %d\n", pid2);
    }

    wait(&st);
    printf("Process 1: end\n");

    printf("--------------------\n");
    return 0;
}
