#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

int main(int argc, char* argv[]) {
  if (argc < 2) {
    printf("Format: dup filename");
    return 4;
  }

  int std_out = dup(1);
  close(1);

  int outf = open(argv[1], O_WRONLY);
  write(outf, "Вывод строки в файл\n", 100);
  write(std_out, "Вывод строки на экран\n", 100);

  close(outf);
  outf = open("/dev/tty", O_WRONLY);
  close(std_out);

  printf("--------------------\n");
  return 0;
}
